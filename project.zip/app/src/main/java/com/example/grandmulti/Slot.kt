package com.example.grandmulti

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.view.View

/** Одна ячейка: своя копия игры на своём виртуальном экране. */
class Slot(private val ctx: Context, val index: Int) {
    companion object { const val W = 1280; const val H = 592; const val DPI = 320 }

    var pkg: String? = null
    private var vd: VirtualDisplay? = null
    // Заглушка, чтобы игра рендерилась, пока панель не на экране (AFK).
    private val dummy = Surface(SurfaceTexture(false).apply { setDefaultBufferSize(W, H) })

    val displayId get() = vd?.display?.displayId ?: -1

    fun start() {
        val p = pkg ?: return
        if (vd == null) {
            val dm = ctx.getSystemService(DisplayManager::class.java)
            vd = dm.createVirtualDisplay(
                "grand-slot-$index", W, H, DPI, dummy,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            )
        }
        val comp = ctx.packageManager.getLaunchIntentForPackage(p)?.component?.flattenToShortString() ?: return
        val id = displayId
        Thread { runCatching { Shell.exec("am start --display $id -n $comp") } }.start()
    }

    fun attach(s: Surface?) { vd?.surface = s ?: dummy }

    fun stop() {
        pkg?.let { p -> Thread { runCatching { Shell.exec("am force-stop $p") } }.start() }
        vd?.release(); vd = null
    }

    /** Пересылает касания из панели в игру (мультитач поддерживается). */
    fun touch(ev: MotionEvent, v: View) {
        if (vd == null) return
        val sx = W.toFloat() / v.width; val sy = H.toFloat() / v.height
        val n = ev.pointerCount
        val props = Array(n) { MotionEvent.PointerProperties().also { p -> ev.getPointerProperties(it, p) } }
        val coords = Array(n) {
            MotionEvent.PointerCoords().also { c -> ev.getPointerCoords(it, c); c.x *= sx; c.y *= sy }
        }
        val e = MotionEvent.obtain(
            ev.downTime, ev.eventTime, ev.action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        runCatching { Injector.send(e, displayId) }
        e.recycle()
    }
}
