package com.example.grandmulti

import android.content.pm.PackageManager
import android.hardware.input.InputManager
import android.os.IBinder
import android.view.InputEvent
import android.view.MotionEvent
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

object Shell {
    fun ready() = Shizuku.pingBinder() &&
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED

    /** Выполняет команду от имени shell через Shizuku (вызывать не в UI-потоке). */
    fun exec(cmd: String) {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        (m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process).waitFor()
    }
}

/** Отправка касаний на конкретный виртуальный экран с правами shell. */
object Injector {
    private val im: Any by lazy {
        val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
        Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
    }
    private val inject by lazy {
        Class.forName("android.hardware.input.IInputManager")
            .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
    }
    private val setDisplay by lazy {
        InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
    }

    fun send(e: MotionEvent, displayId: Int) {
        setDisplay.invoke(e, displayId)
        inject.invoke(im, e, 0) // 0 = async
    }
}
