package com.example.grandmulti

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {
    private val slots by lazy { List(10) { Slot(this, it) } }
    private val tileSurf = arrayOfNulls<Surface>(10)
    private lateinit var root: FrameLayout
    private lateinit var full: FrameLayout
    private lateinit var fullTex: TextureView
    private var open = -1

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("")
        startForegroundService(Intent(this, KeepAliveService::class.java))
        if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != 0) Shizuku.requestPermission(1)

        val prefs = getSharedPreferences("slots", MODE_PRIVATE)
        slots.forEach { it.pkg = prefs.getString("pkg${it.index}", null) }

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Button(this).apply {
            text = "Запустить все"
            setOnClickListener {
                if (!Shell.ready()) toast("Включи Shizuku и дай приложению доступ")
                else slots.forEach { s -> s.start() }
            }
        })
        val grid = GridLayout(this).apply { columnCount = 2 }
        slots.forEach { s -> grid.addView(tile(s)) }
        col.addView(ScrollView(this).apply { addView(grid) })
        root.addView(col)

        // Полноэкранный режим одной панели
        full = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.BLACK) }
        fullTex = TextureView(this)
        fullTex.surfaceTextureListener = listener { st -> if (open >= 0) slots[open].attach(Surface(st)) }
        fullTex.setOnTouchListener { v, e -> if (open >= 0) slots[open].touch(e, v); true }
        full.addView(fullTex, -1, -1)
        full.addView(Button(this).apply { text = "⬇ Свернуть (AFK)"; setOnClickListener { collapse() } })
        root.addView(full, -1, -1)
        setContentView(root)
    }

    private fun tile(s: Slot): View {
        val w = resources.displayMetrics.widthPixels / 2 - 8
        val f = FrameLayout(this).apply { layoutParams = GridLayout.LayoutParams().apply { width = w; height = w * Slot.H / Slot.W; setMargins(4, 4, 4, 4) } }
        f.setBackgroundColor(Color.DKGRAY)
        val tv = TextureView(this)
        tv.surfaceTextureListener = listener { st -> tileSurf[s.index] = Surface(st).also { sf -> if (open < 0) s.attach(sf) } }
        f.addView(tv, -1, -1)
        val label = TextView(this).apply {
            text = s.pkg ?: "Добавить приложение"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(if (s.pkg == null) Color.TRANSPARENT else 0x33000000)
        }
        f.addView(label, -1, -1)
        f.setOnClickListener { if (s.pkg == null) pick(s, label) else expand(s) }
        f.setOnLongClickListener { pick(s, label); true } // долгий тап: сменить копию
        return f
    }

    private fun pick(s: Slot, label: TextView) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .sortedBy { if (it.first.contains("grand", true)) "0${it.first}" else "1${it.first}" }
        AlertDialog.Builder(this).setTitle("Выбери копию игры")
            .setItems(apps.map { "${it.first}\n${it.second}" }.toTypedArray()) { _, i ->
                s.pkg = apps[i].second
                getSharedPreferences("slots", MODE_PRIVATE).edit().putString("pkg${s.index}", s.pkg).apply()
                label.text = s.pkg; label.setBackgroundColor(0x33000000)
                if (Shell.ready()) s.start() else toast("Включи Shizuku")
            }.show()
    }

    private fun expand(s: Slot) {
        open = s.index
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        full.visibility = View.VISIBLE
        fullTex.surfaceTexture?.let { s.attach(Surface(it)) }
        s.start()
    }

    private fun collapse() {
        val i = open; open = -1
        full.visibility = View.GONE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        slots[i].attach(tileSurf[i])
    }

    private fun listener(onReady: (SurfaceTexture) -> Unit) = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = onReady(st)
        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
        override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
